/********************************************************************
   Please set gmock directiories to
    Tool-> Options -> Projects and Solutions -> VC++ Directories
*********************************************************************/
#include "stdafx.h"
#include <gtest/gtest.h>
#include "PrintInfo.h"

using namespace testing;

#pragma comment(lib, "gtest.lib")


class CGetDataTest:public testing::Environment
{
public:
	virtual void SetUp()
	{
		//TODO: Do something before every case
	}

	virtual void TearDown()
	{
		//TODO: Do something after every case
	}
};

int main(int argc, char** argv)
{
	testing::InitGoogleTest(&argc, argv);
	testing::AddGlobalTestEnvironment(new CGetDataTest);
	return RUN_ALL_TESTS();
}

