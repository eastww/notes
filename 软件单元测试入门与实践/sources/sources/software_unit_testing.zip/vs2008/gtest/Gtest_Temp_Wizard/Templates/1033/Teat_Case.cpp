#include "stdafx.h"
#include <gtest/gtest.h>
#include "PrintInfo.h"

TEST(case_name,test_name)
{

}