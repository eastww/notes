#include "stdafx.h"
#include<iostream>
#include<stdarg.h>
#include "PrintInfo.h"

/**
*   \brief Print information to the screen
*   \param [in]format:Format set
*/
void Print(const char* format, ...)
{
#if _Print_
	va_list args;
	va_start(args, format);

	int nBuf;
	char szBuffer[4096]={0};

	nBuf = vsnprintf(szBuffer, _countof(szBuffer), format, args);

	va_end(args);

	std::cout << szBuffer << std::endl;
#endif
}

/**
*   \brief Print information to the screen
*   \param [in]format:Format set
*/
void Print(const wchar_t* format, ...)
{
#if _Print_
	va_list args;
	va_start(args, format);

	int nBuf;
	wchar_t szBuffer[4096]={0};

	nBuf = vswprintf(szBuffer, _countof(szBuffer), format, args);

	va_end(args);

	std::wcout << szBuffer << std::endl;
#endif
}