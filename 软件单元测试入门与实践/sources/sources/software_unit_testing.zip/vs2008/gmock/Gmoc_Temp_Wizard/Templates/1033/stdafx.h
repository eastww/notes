// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

#include <stdio.h>
#include <tchar.h>


#define ASSERT_BETWEEN(val1, val2, valEx) \
	ASSERT_LE(val1, valEx); \
	ASSERT_LE(valEx, val2)

#define EXPECT_BETWEEN(val1, val2, valEx) \
	EXPECT_LE(val1, valEx); \
	EXPECT_LE(valEx, val2)
// TODO: reference additional headers your program requires here
