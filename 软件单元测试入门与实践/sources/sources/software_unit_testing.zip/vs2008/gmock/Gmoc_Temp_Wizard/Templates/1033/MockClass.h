#include <gmock/gmock.h>

class CMockClass
{
	MOCK_METHOD4(funcName, int(int arg1, int arg2, int arg3, int arg4));
};