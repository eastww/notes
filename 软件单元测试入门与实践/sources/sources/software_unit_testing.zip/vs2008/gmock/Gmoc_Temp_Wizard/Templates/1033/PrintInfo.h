#pragma once

#define _Print_ 1

/**
*   \brief Print information to the screen
*   \param [in]format:Format set
*/
void Print(const char* format, ...);

/**
*   \brief Print information to the screen
*   \param [in]format:Format set
*/
void Print(const wchar_t* format, ...);